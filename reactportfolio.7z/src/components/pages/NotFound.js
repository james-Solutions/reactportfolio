import React, { Component } from 'react';
import AppNavBar from '../layout/AppNavBar';

class NotFound extends Component {
  render() {
    return (
      <div>
        <AppNavBar />
        404 Not Found
      </div>
    );
  }
}

export default NotFound;
