import React, { Component } from 'react';
import { Col, Card } from 'react-materialize';
import AppNavBar from '../layout/AppNavBar';

class About extends Component {
  render() {
    return (
      <div id="about-container">
        <AppNavBar isAbout="active" />
        <div className="container">
          <div className="row">
            <Col s={12}>
              <h1>
                About <span className="light-blue-text">Me</span>
              </h1>
            </Col>
            <div className="row">
              <Col m={4} s={12}>
                <img
                  src="project-images/nigra-cropped.png"
                  alt="James"
                  style={{
                    borderRadius: '50%',
                    border: '#03a9f4 3px solid'
                  }}
                />
              </Col>
              <Col m={8} s={12}>
                <Card>
                  <h2 className="center-align">
                    <span className="light-blue-text">BIO</span>
                  </h2>
                  <p>
                    I grew up in central Arkansas and graduated from ITT
                    Technical Institute in 2009 wtih an Associates in Software
                    Application Programming. Afterwards I joined the U.S. Army
                    as a Fire Support Specialist. I deployed to Afghanistan in
                    2012, returning in 2013. I was honorably discharged as a
                    Sergeant after 4 years of service. After the military I was
                    lucky enough to do a travelling position with ABC Financial
                    Services. In which I conducted my own travel around the U.S.
                    and Canada to provide training and support for ABC Clients.
                  </p>
                  <br />
                  <p>
                    I am now attending the University of Arkansas at Little Rock
                    for Computer Science and Mathematics. I have several
                    interests in both fields. Of late I have learned the
                    JavaScript React Library, used to build this website! I am
                    enjoying expanding my web development skills. As well, I
                    have been making Python projects to interact with SageMath
                    to create graphs and scatter plots of data. Machine learning
                    is another one of these interests, I am looking forward to
                    learning to combine Mathematics and Computer Science.
                  </p>
                </Card>
              </Col>
            </div>
            <div className="row">
              <Col m={6} s={12}>
                <Card className="white-text light-blue lighten-2">
                  <h3>ABC Financial Services</h3>
                  <h6>OnSite Implementation Manager</h6>
                  <p style={{ fontStyle: 'italic' }}>May 2015 - Jan 2017</p>
                  <hr />
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad
                    iure, quam maxime alias distinctio sit cumque consequuntur!
                    Voluptate suscipit temporibus, illum a quos ducimus
                    asperiores pariatur voluptatum impedit numquam harum.
                  </p>
                </Card>
              </Col>
              <Col m={6} s={12}>
                <Card className="white-text light-blue lighten-2">
                  <h3>U.S. Army</h3>
                  <h6>Fire Support Sergeant</h6>
                  <p style={{ fontStyle: 'italic' }}>Mar 2011 - Apr 2015</p>
                  <hr />
                  <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                    Consequuntur ea quaerat ipsum vero blanditiis porro numquam
                    facilis id quibusdam, magnam totam eaque possimus tempora,
                    in, fugit molestias quos est! Officiis expedita cupiditate
                    laboriosam, quod, ipsam, tenetur velit quibusdam magni
                    inventore voluptatum mollitia nostrum saepe ab nulla
                    architecto? Impedit, sunt voluptatibus!
                  </p>
                </Card>
              </Col>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default About;
